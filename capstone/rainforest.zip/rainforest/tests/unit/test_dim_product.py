# This is a test file for dim_product.py
