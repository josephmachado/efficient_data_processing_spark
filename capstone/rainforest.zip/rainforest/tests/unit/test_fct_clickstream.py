# This is a test file for fct_clickstream.py
