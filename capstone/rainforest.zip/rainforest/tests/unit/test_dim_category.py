# This is a test file for dim_category.py
